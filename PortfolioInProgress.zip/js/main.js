$(document).ready(function(){
    $(".imgLiquidFill").imgLiquid();
});